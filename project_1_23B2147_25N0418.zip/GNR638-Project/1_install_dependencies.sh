#!/usr/bin/env bash
# =============================================================================
# 1_install_dependencies.sh
# Run this FIRST, with internet access.
# Installs all Python packages + system deps needed by the notebook.
# =============================================================================

set -e  # exit on any error

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " Step 1 — System dependencies (tesseract OCR)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if command -v apt-get &>/dev/null; then
    apt-get update -q && apt-get install -y -q tesseract-ocr libgl1
    echo "✅ System packages installed via apt-get"
elif command -v brew &>/dev/null; then
    brew install tesseract
    echo "✅ System packages installed via brew"
else
    echo "⚠️  Could not detect apt-get or brew."
    echo "   Please install Tesseract manually: https://github.com/tesseract-ocr/tesseract"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo " Step 2 — Python packages"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

pip install \
    torch \
    torchvision \
    timm \
    opencv-python-headless \
    pillow \
    matplotlib \
    scikit-learn \
    scipy \
    numpy \
    tqdm \
    transformers \
    accelerate \
    requests \
    easyocr \
    pandas \
    pytesseract \
    -q

echo ""
echo "✅ All Python packages installed."
echo ""
echo "Next step → run:  bash 2_download_maps.sh"
